Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchValue:'',
    historyList:[
      {
        historyW:'美孚',
      },
      {
        historyW: '美孚',
      },
      {
        historyW: '美孚',
      },
      {
        historyW: '美孚',
      },
    ]
  },

})